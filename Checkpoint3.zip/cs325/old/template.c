//Asmt ???
//Tori Vaz
//CS 325
//?? ?? 2016

#include<stdio.h>
#include<sys/types.h>
#include<sys/sockets.h>

int main(int argc, char *argv[]) {
  printf("Hello, %s\n", argv[1]);
  return 0;
}
